<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Πάρε & Έφυγες — Coffee & Snack | Καριώτες, Λευκάδα</title>
  <meta name="description" content="Καφέ & Snack στους Καριώτες Λευκάδας. Εξαιρετικός καφές, οικογενειακή ατμόσφαιρα, μηχανόφιλο πνεύμα.">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Bebas+Neue&family=Lora:ital,wght@0,400;0,500;1,400;1,500&display=swap" rel="stylesheet">

  <style>
    /* ── RESET ─────────────────────────────────────────────────────── */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --white:   #FFFFFF;
      --off:     #F8F6F2;
      --warm:    #F0EBE1;
      --border:  #DDD7CC;
      --dark:    #110A04;
      --espresso:#1C0E06;
      --brown:   #4A2810;
      --caramel: #7A4E24;
      --amber:   #C8872A;
      --gold:    #E0A840;
      --text:    #1C1008;
      --muted:   #7A5A3A;
      --ease:    cubic-bezier(0.4, 0, 0.2, 1);
    }

    html { scroll-behavior: smooth; }

    body {
      font-family: 'Lora', Georgia, serif;
      background: var(--white);
      color: var(--text);
      overflow-x: hidden;
    }

    /* ── REVEAL ANIMATIONS ─────────────────────────────────────────── */
    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition: opacity 0.7s var(--ease), transform 0.7s var(--ease);
    }
    .reveal.visible { opacity: 1; transform: translateY(0); }
    .reveal-delay-1 { transition-delay: 0.1s; }
    .reveal-delay-2 { transition-delay: 0.2s; }
    .reveal-delay-3 { transition-delay: 0.3s; }
    .reveal-delay-4 { transition-delay: 0.4s; }

    /* ── NAVIGATION ────────────────────────────────────────────────── */
    #nav {
      position: fixed;
      inset: 0 0 auto;
      z-index: 500;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1.25rem 2.5rem;
      transition: padding 0.4s var(--ease), background 0.4s, box-shadow 0.4s;
    }
    #nav.scrolled {
      background: rgba(255, 255, 255, 0.97);
      backdrop-filter: blur(12px);
      padding: 0.75rem 2.5rem;
      box-shadow: 0 1px 0 var(--border), 0 4px 24px rgba(0,0,0,0.05);
    }

    .nav-logo {
      height: 50px;
      width: auto;
      display: block;
      transition: height 0.4s var(--ease);
      mix-blend-mode: multiply;
    }
    #nav.scrolled .nav-logo { height: 38px; }

    .nav-links {
      display: flex;
      gap: 2.25rem;
      list-style: none;
    }
    .nav-links a {
      color: var(--brown);
      text-decoration: none;
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.92rem;
      letter-spacing: 0.14em;
      position: relative;
      transition: color 0.3s;
    }
    .nav-links a::after {
      content: '';
      position: absolute;
      left: 0; bottom: -3px;
      width: 0; height: 1.5px;
      background: var(--amber);
      transition: width 0.3s var(--ease);
    }
    .nav-links a:hover { color: var(--amber); }
    .nav-links a:hover::after { width: 100%; }

    .nav-right { display: flex; align-items: center; gap: 0.75rem; }

    .lang-pill {
      display: flex;
      align-items: center;
      border: 1.5px solid var(--border);
      border-radius: 999px;
      padding: 3px;
      gap: 2px;
      background: var(--white);
    }
    .lang-btn {
      background: none;
      border: none;
      color: var(--muted);
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.8rem;
      letter-spacing: 0.1em;
      padding: 0.28rem 0.7rem;
      border-radius: 999px;
      cursor: pointer;
      transition: all 0.3s;
    }
    .lang-btn.active {
      background: var(--brown);
      color: var(--white);
    }

    .hamburger {
      display: none;
      flex-direction: column;
      gap: 5px;
      cursor: pointer;
      background: none;
      border: none;
      padding: 4px;
    }
    .hamburger span {
      display: block;
      width: 22px;
      height: 2px;
      background: var(--brown);
      border-radius: 2px;
      transition: all 0.3s;
    }

    /* ── HERO ──────────────────────────────────────────────────────── */
    #hero {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--white);
      padding: 6rem 2rem 3rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }

    #hero::after {
      content: '';
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: 200px;
      background: linear-gradient(to top, var(--off), transparent);
      pointer-events: none;
    }

    #hero::before {
      content: '';
      position: absolute;
      top: 7rem; left: 2.5rem;
      width: 60px; height: 60px;
      border-top: 1.5px solid var(--border);
      border-left: 1.5px solid var(--border);
      pointer-events: none;
    }

    .hero-ghost {
      position: absolute;
      bottom: -0.1em;
      left: 50%;
      transform: translateX(-50%);
      font-family: 'Bebas Neue', sans-serif;
      font-size: clamp(5rem, 15vw, 14rem);
      color: transparent;
      -webkit-text-stroke: 1px var(--border);
      white-space: nowrap;
      pointer-events: none;
      user-select: none;
      letter-spacing: 0.1em;
      opacity: 0.28;
      line-height: 1;
    }

    .hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      max-width: 820px;
    }

    .hero-logo-wrap {
      width: 100%;
      max-width: 500px;
      margin-bottom: 1.25rem;
      opacity: 0;
      animation: fadeUp 0.9s 0.2s var(--ease) forwards;
      border-top: 1px solid var(--border);
      border-bottom: 1px solid var(--border);
      padding: 1rem 0;
    }
    .hero-logo-wrap img {
      width: 100%;
      height: auto;
      display: block;
      mix-blend-mode: multiply;
    }

    .hero-tagline {
      font-family: 'Bebas Neue', sans-serif;
      font-size: clamp(0.8rem, 1.5vw, 1rem);
      letter-spacing: 0.38em;
      color: var(--muted);
      text-transform: uppercase;
      margin-bottom: 1.5rem;
      opacity: 0;
      animation: fadeUp 0.9s 0.38s var(--ease) forwards;
    }

    .hero-divider {
      width: 64px;
      height: 1.5px;
      background: var(--amber);
      margin: 0 auto 1.5rem;
      opacity: 0;
      animation: fadeUp 0.9s 0.5s var(--ease) forwards;
    }

    .hero-sub {
      font-family: 'Lora', serif;
      font-style: italic;
      font-size: clamp(0.95rem, 2vw, 1.15rem);
      color: var(--muted);
      line-height: 1.85;
      max-width: 440px;
      opacity: 0;
      animation: fadeUp 0.9s 0.65s var(--ease) forwards;
      margin-bottom: 2rem;
    }

    .hero-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
      flex-wrap: wrap;
      justify-content: center;
      opacity: 0;
      animation: fadeUp 0.9s 0.85s var(--ease) forwards;
    }

    .btn-fill {
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
      background: var(--brown);
      color: var(--white);
      text-decoration: none;
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.95rem;
      letter-spacing: 0.14em;
      padding: 0.85rem 2.1rem;
      border-radius: 3px;
      transition: background 0.3s, transform 0.3s, box-shadow 0.3s;
    }
    .btn-fill:hover {
      background: var(--amber);
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(200,135,42,0.3);
    }

    .btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
      border: 1.5px solid var(--brown);
      color: var(--brown);
      text-decoration: none;
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.95rem;
      letter-spacing: 0.14em;
      padding: 0.85rem 2.1rem;
      border-radius: 3px;
      transition: all 0.3s;
    }
    .btn-outline:hover {
      background: var(--brown);
      color: var(--white);
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    /* ── TICKER STRIP ──────────────────────────────────────────────── */
    .ticker {
      background: var(--espresso);
      height: 46px;
      display: flex;
      align-items: center;
      overflow: hidden;
    }
    .ticker-track {
      display: flex;
      animation: tickScroll 28s linear infinite;
      white-space: nowrap;
    }
    .ticker-track:hover { animation-play-state: paused; }
    .ticker-item {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.8rem;
      letter-spacing: 0.3em;
      color: var(--amber);
      padding: 0 2rem;
      flex-shrink: 0;
    }
    .ticker-dot {
      color: rgba(200,135,42,0.4);
      padding: 0 0.5rem;
    }
    @keyframes tickScroll {
      0%   { transform: translateX(0); }
      100% { transform: translateX(-50%); }
    }

    /* ── SHARED LAYOUT ─────────────────────────────────────────────── */
    .wrap  { max-width: 1200px; margin: 0 auto; padding: 0 2rem; }
    .sec   { padding: 7rem 2rem; }

    .eyebrow {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.76rem;
      letter-spacing: 0.32em;
      color: var(--amber);
      text-transform: uppercase;
      display: block;
      margin-bottom: 0.75rem;
    }

    .sec-title {
      font-family: 'Playfair Display', serif;
      font-size: clamp(2rem, 4vw, 3.2rem);
      font-weight: 700;
      line-height: 1.12;
      color: var(--dark);
    }
    .sec-title.light { color: var(--white); }

    .sec-body {
      font-family: 'Lora', serif;
      font-size: 1.05rem;
      line-height: 1.9;
      color: var(--muted);
    }
    .sec-body.light { color: rgba(255,255,255,0.6); }

    .thin-rule {
      width: 48px;
      height: 1.5px;
      background: var(--amber);
      margin: 1.5rem 0;
      border-radius: 2px;
    }
    .thin-rule.center { margin-left: auto; margin-right: auto; }

    /* ── ABOUT ─────────────────────────────────────────────────────── */
    #about { background: var(--off); }

    .about-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 5rem;
      align-items: center;
    }

    .about-visual {
      position: relative;
    }
    .about-img-frame {
      border-radius: 6px;
      overflow: visible;
      position: relative;
      background: var(--white);
      border: 1px solid var(--border);
      padding: 2rem;
    }
    .about-img-frame img {
      width: 100%;
      height: auto;
      display: block;
      border-radius: 3px;
      mix-blend-mode: multiply;
    }
    .about-img-frame::after {
      content: '';
      position: absolute;
      bottom: -14px;
      right: -14px;
      width: 70px;
      height: 70px;
      border: 2px solid rgba(200,135,42,0.25);
      border-radius: 4px;
      z-index: -1;
    }
    .about-img-frame::before {
      content: '';
      position: absolute;
      top: -1px; left: 2rem; right: 2rem;
      height: 2px;
      background: var(--amber);
      border-radius: 0 0 2px 2px;
    }

    .about-stats {
      display: flex;
      gap: 2.5rem;
      margin-top: 2.75rem;
      padding-top: 2.5rem;
      border-top: 1px solid var(--border);
    }
    .stat-num {
      font-family: 'Playfair Display', serif;
      font-size: 2.4rem;
      font-weight: 900;
      color: var(--amber);
      line-height: 1;
      display: block;
    }
    .stat-label {
      font-family: 'Lora', serif;
      font-size: 0.78rem;
      color: var(--muted);
      margin-top: 0.2rem;
      display: block;
    }

    /* ── COFFEE ────────────────────────────────────────────────────── */
    #coffee { background: var(--warm); }

    .coffee-header { text-align: center; margin-bottom: 4rem; }

    .coffee-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.25rem;
    }
    .coffee-card {
      background: var(--white);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 2.25rem 1.5rem;
      text-align: center;
      transition: border-color 0.3s, transform 0.3s, box-shadow 0.3s;
      position: relative;
      overflow: hidden;
    }
    .coffee-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
      background: var(--amber);
      transform: scaleX(0);
      transition: transform 0.35s var(--ease);
    }
    .coffee-card:hover {
      border-color: var(--amber);
      transform: translateY(-4px);
      box-shadow: 0 12px 36px rgba(0,0,0,0.07);
    }
    .coffee-card:hover::before { transform: scaleX(1); }

    .coffee-icon {
      width: 50px;
      height: 50px;
      margin: 0 auto 1.25rem;
      color: var(--amber);
      display: block;
    }
    .coffee-name {
      font-family: 'Playfair Display', serif;
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--dark);
      margin-bottom: 0.65rem;
    }
    .coffee-desc {
      font-family: 'Lora', serif;
      font-size: 0.85rem;
      color: var(--muted);
      line-height: 1.75;
    }

    /* ── VIBE / COMMUNITY ──────────────────────────────────────────── */
    #vibe {
      background: var(--espresso);
      padding: 8rem 2rem;
      position: relative;
      overflow: hidden;
    }

    .vibe-bg-logo {
      position: absolute;
      right: -5%;
      top: 50%;
      transform: translateY(-50%);
      width: 55%;
      max-width: 750px;
      opacity: 0.15;
      filter: invert(1);
      pointer-events: none;
      object-position: right center;
    }

    .vibe-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 5rem;
      align-items: center;
      position: relative;
      z-index: 1;
    }

    .vibe-quote {
      font-family: 'Playfair Display', serif;
      font-style: italic;
      font-size: clamp(1.7rem, 3vw, 2.5rem);
      color: var(--white);
      line-height: 1.45;
      padding-left: 1.75rem;
      border-left: 2.5px solid var(--amber);
    }
    .vibe-quote cite {
      display: block;
      margin-top: 1.25rem;
      font-style: normal;
      font-family: 'Bebas Neue', sans-serif;
      letter-spacing: 0.16em;
      font-size: 0.82rem;
      color: rgba(200,135,42,0.6);
    }

    .pillar-list { display: flex; flex-direction: column; gap: 2rem; }

    .pillar {
      display: flex;
      align-items: flex-start;
      gap: 1.25rem;
    }
    .pillar-icon-wrap {
      width: 44px;
      height: 44px;
      flex-shrink: 0;
      border: 1px solid rgba(200,135,42,0.2);
      background: rgba(200,135,42,0.06);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--amber);
      transition: background 0.3s, border-color 0.3s;
    }
    .pillar:hover .pillar-icon-wrap {
      background: rgba(200,135,42,0.14);
      border-color: rgba(200,135,42,0.4);
    }
    .pillar-title {
      font-family: 'Playfair Display', serif;
      font-size: 1.05rem;
      font-weight: 700;
      color: var(--white);
      margin-bottom: 0.3rem;
    }
    .pillar-body {
      font-family: 'Lora', serif;
      font-size: 0.88rem;
      color: rgba(255,255,255,0.45);
      line-height: 1.7;
    }

    /* ── REVIEWS ───────────────────────────────────────────────────── */
    #reviews { background: var(--white); }

    .reviews-header { text-align: center; margin-bottom: 3.5rem; }

    .reviews-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
    }
    .reviews-grid.cols-3 {
      grid-template-columns: repeat(3, 1fr);
    }
    .reviews-grid.cols-3 .review-card:last-child:nth-child(3n+2) {
      grid-column: 2;
    }

    .review-card {
      background: var(--off);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 2rem;
      position: relative;
      transition: box-shadow 0.3s, transform 0.3s, border-color 0.3s;
    }
    .review-card:hover {
      box-shadow: 0 10px 32px rgba(0,0,0,0.07);
      transform: translateY(-3px);
      border-color: rgba(200,135,42,0.3);
    }
    .review-stars {
      font-size: 0.95rem;
      color: var(--amber);
      letter-spacing: 2px;
      margin-bottom: 1rem;
      display: block;
    }
    .review-text {
      font-family: 'Lora', serif;
      font-style: italic;
      font-size: 0.95rem;
      line-height: 1.8;
      color: var(--brown);
      margin-bottom: 1.5rem;
    }
    .review-author-row {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .review-avatar {
      width: 38px;
      height: 38px;
      border-radius: 50%;
      background: var(--brown);
      color: var(--white);
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .review-name {
      font-family: 'Lora', serif;
      font-weight: 500;
      font-size: 0.9rem;
      color: var(--dark);
    }
    .review-source {
      font-size: 0.74rem;
      color: var(--muted);
      margin-top: 2px;
    }
    .g-icon {
      position: absolute;
      top: 1.5rem;
      right: 1.5rem;
      opacity: 0.2;
    }
    .reviews-cta { text-align: center; margin-top: 3rem; }

    .btn-outlined {
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
      border: 1.5px solid var(--border);
      color: var(--muted);
      text-decoration: none;
      font-family: 'Bebas Neue', sans-serif;
      letter-spacing: 0.14em;
      font-size: 0.92rem;
      padding: 0.8rem 2rem;
      border-radius: 3px;
      transition: all 0.3s;
    }
    .btn-outlined:hover {
      border-color: var(--amber);
      color: var(--amber);
    }

    /* ── LOCATION ──────────────────────────────────────────────────── */
    #location { padding: 0; overflow: hidden; }

    .location-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      min-height: 560px;
    }

    .location-info {
      background: var(--warm);
      padding: 5rem 4.5rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      border-right: 1px solid var(--border);
    }

    .hours-table { margin-top: 2rem; }
    .hours-row {
      display: flex;
      justify-content: space-between;
      padding: 0.65rem 0;
      border-bottom: 1px solid var(--border);
      font-size: 0.9rem;
    }
    .hours-day  { color: var(--muted); font-family: 'Lora', serif; }
    .hours-time { color: var(--dark);  font-family: 'Lora', serif; font-weight: 500; }
    .hours-time.closed { color: var(--border); }

    .location-contacts {
      margin-top: 2.5rem;
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
    }
    .contact-row {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      font-family: 'Lora', serif;
      font-size: 0.9rem;
      color: var(--muted);
    }
    .contact-row svg { color: var(--amber); flex-shrink: 0; width: 17px; height: 17px; }

    .location-map iframe {
      width: 100%;
      height: 100%;
      min-height: 560px;
      display: block;
      border: none;
    }

    /* ── FOOTER ────────────────────────────────────────────────────── */
    footer {
      background: var(--espresso);
      padding: 4rem 2rem 2.5rem;
      border-top: 1px solid rgba(255,255,255,0.06);
    }
    .footer-inner {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 2.25rem;
    }
    .footer-logo {
      height: 52px;
      filter: brightness(0) invert(1);
      opacity: 0.5;
    }
    .footer-links {
      display: flex;
      gap: 2rem;
      list-style: none;
      flex-wrap: wrap;
      justify-content: center;
    }
    .footer-links a {
      color: rgba(255,255,255,0.3);
      text-decoration: none;
      font-family: 'Bebas Neue', sans-serif;
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      transition: color 0.3s;
    }
    .footer-links a:hover { color: var(--amber); }
    .footer-copy {
      font-family: 'Lora', serif;
      font-size: 0.75rem;
      color: rgba(255,255,255,0.18);
      text-align: center;
    }

    /* ── GALLERY ───────────────────────────────────────────────────── */
    #gallery { background: var(--off); }

    .gallery-header { text-align: center; margin-bottom: 3rem; }

    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      grid-auto-rows: 220px;
      gap: 0.85rem;
    }

    .gallery-item {
      border-radius: 8px;
      overflow: hidden;
      position: relative;
      min-height: 0;
      cursor: pointer;
      background: var(--warm);
    }
    .gallery-item img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
      transition: transform 0.55s var(--ease);
    }
    .gallery-item:hover img { transform: scale(1.06); }

    .gallery-item::after {
      content: '';
      position: absolute;
      inset: 0;
      background: rgba(28,14,6,0);
      transition: background 0.4s;
      pointer-events: none;
    }
    .gallery-item:hover::after { background: rgba(28,14,6,0.18); }

    .gallery-featured {
      grid-column: 1 / 3;
      grid-row: 1 / 3;
    }
    .gallery-wide { grid-column: span 2; }

    .lightbox {
      position: fixed;
      inset: 0;
      background: rgba(17,10,4,0.96);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
      padding: 2rem;
    }
    .lightbox.open { opacity: 1; pointer-events: all; }
    .lightbox img {
      max-width: 90vw;
      max-height: 85vh;
      object-fit: contain;
      border-radius: 6px;
      box-shadow: 0 24px 80px rgba(0,0,0,0.6);
    }
    .lightbox-close {
      position: absolute;
      top: 1.5rem; right: 1.5rem;
      background: none; border: none;
      color: rgba(255,255,255,0.7);
      font-size: 2rem;
      cursor: pointer;
      line-height: 1;
      padding: 0.25rem 0.75rem;
      transition: color 0.2s;
    }
    .lightbox-close:hover { color: var(--amber); }

    /* ── MOBILE ────────────────────────────────────────────────────── */
    @media (max-width: 1024px) {
      .coffee-grid { grid-template-columns: repeat(2, 1fr); }
      .gallery-grid { grid-template-columns: repeat(3, 1fr); grid-auto-rows: 180px; }
      .gallery-featured { grid-column: 1 / 3; grid-row: 1 / 3; }
      .gallery-wide { grid-column: span 1; }
    }

    @media (max-width: 860px) {
      .sec { padding: 5rem 1.5rem; }
      #vibe { padding: 5rem 1.5rem; }
      .nav-links {
        position: fixed;
        inset: 0 0 0 auto;
        width: 280px;
        background: rgba(255,255,255,0.99);
        backdrop-filter: blur(16px);
        flex-direction: column;
        justify-content: center;
        padding: 3rem 2.5rem;
        transform: translateX(100%);
        transition: transform 0.4s var(--ease);
        box-shadow: -4px 0 32px rgba(0,0,0,0.08);
        gap: 2.5rem;
      }
      .nav-links.open { transform: translateX(0); }
      .nav-links a { color: var(--brown); font-size: 1.3rem; }
      .hamburger { display: flex; }
      .about-grid { grid-template-columns: 1fr; gap: 2.5rem; }
      .vibe-grid { grid-template-columns: 1fr; gap: 2.5rem; }
      .location-grid { grid-template-columns: 1fr; }
      .about-visual { order: -1; }
      .about-img-frame { padding: 1.25rem; }
      .location-info { padding: 3rem 2rem; border-right: none; border-bottom: 1px solid var(--border); }
      .location-map iframe { min-height: 300px; }
      #nav { padding: 1rem 1.5rem; }
      #nav.scrolled { padding: 0.75rem 1.5rem; }
      .vibe-bg-logo { width: 70%; opacity: 0.1; }
      .gallery-grid { grid-template-columns: repeat(2, 1fr); grid-auto-rows: 180px; }
      .gallery-featured { grid-column: 1 / -1; grid-row: span 1; }
      .gallery-wide { grid-column: span 1; }
    }

    @media (max-width: 560px) {
      .sec { padding: 3.5rem 1.25rem; }
      #vibe { padding: 3.5rem 1.25rem; }
      #hero { padding: 5.5rem 1.25rem 2.5rem; }
      .hero-logo-wrap { max-width: 300px; }
      .hero-ghost { display: none; }
      .coffee-grid { grid-template-columns: repeat(2, 1fr); gap: 0.65rem; }
      .coffee-card { padding: 1.5rem 1rem; }
      .reviews-grid { grid-template-columns: 1fr; }
      .hero-actions { flex-direction: column; width: 100%; }
      .btn-fill, .btn-outline { width: 100%; justify-content: center; }
      .about-stats { flex-wrap: wrap; gap: 1.25rem; }
      .about-stats > div { flex: 1; min-width: 80px; }
      .pillar-list { gap: 1.5rem; }
      .location-map iframe { min-height: 250px; }
      .vibe-bg-logo { display: none; }
      .gallery-grid { grid-template-columns: repeat(2, 1fr); grid-auto-rows: 150px; }
      .gallery-featured { grid-column: 1 / -1; }
      .sec-title { font-size: clamp(1.7rem, 7vw, 2.8rem); }
      .vibe-quote { font-size: clamp(1.3rem, 5vw, 1.8rem); }
      .footer-links { gap: 1rem; }
      .nav-links { width: 100%; }
    }
  </style>
</head>
<body>

<!-- ═══ NAVIGATION ══════════════════════════════════════════════════════ -->
<nav id="nav">
  <a href="#hero" aria-label="Home">
    <img src="<?php echo get_template_directory_uri(); ?>/Logo.jpeg" alt="Πάρε & Έφυγες" class="nav-logo">
  </a>

  <ul class="nav-links" id="navLinks">
    <li><a href="#about"    data-i18n="nav_about">Σχετικά</a></li>
    <li><a href="#coffee"   data-i18n="nav_coffee">Ο Καφές μας</a></li>
    <li><a href="#vibe"     data-i18n="nav_vibe">Η Παρέα</a></li>
    <li><a href="#reviews"  data-i18n="nav_reviews">Κριτικές</a></li>
    <li><a href="#gallery"  data-i18n="nav_gallery">Φωτογραφίες</a></li>
    <li><a href="#location" data-i18n="nav_loc">Εύρεση</a></li>
  </ul>

  <div class="nav-right">
    <div class="lang-pill" role="group" aria-label="Language">
      <button class="lang-btn active" id="btnEl" onclick="setLang('el')" aria-pressed="true">GR</button>
      <button class="lang-btn"        id="btnEn" onclick="setLang('en')" aria-pressed="false">EN</button>
    </div>
    <button class="hamburger" id="hamburger" aria-label="Μενού" onclick="toggleMenu()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>


<!-- ═══ HERO ════════════════════════════════════════════════════════════ -->
<section id="hero">
  <div class="hero-ghost" aria-hidden="true">COFFEE</div>

  <div class="hero-inner">
    <div class="hero-logo-wrap">
      <img src="<?php echo get_template_directory_uri(); ?>/Logo.jpeg" alt="Πάρε & Έφυγες — Coffee & Snack">
    </div>

    <p class="hero-tagline" data-i18n="hero_tagline">Coffee &amp; Snack · Καριώτες, Λευκάδα</p>

    <div class="hero-divider"></div>

    <p class="hero-sub" data-i18n="hero_sub">
      Ή μείνε — δεν μας πειράζει.<br>
      Η καλύτερη παρέα ξεκινά πάντα με έναν καλό καφέ.
    </p>

    <div class="hero-actions">
      <a href="#about" class="btn-fill">
        <span data-i18n="hero_cta1">Ανακάλυψέ μας</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </a>
      <a href="#location" class="btn-outline">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        <span data-i18n="hero_cta2">Βρες μας</span>
      </a>
    </div>
  </div>
</section>


<!-- ═══ TICKER ═══════════════════════════════════════════════════════════ -->
<div class="ticker" aria-hidden="true">
  <div class="ticker-track">
    <span class="ticker-item">COFFEE</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΚΑΡΙΩΤΕΣ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΜΗΧΑΝΗ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΠΑΡΕΑ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΛΕΥΚΑΔΑ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">SNACK</span><span class="ticker-dot">·</span>
    <span class="ticker-item">FAMILY</span><span class="ticker-dot">·</span>
    <span class="ticker-item">COFFEE</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΚΑΡΙΩΤΕΣ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΜΗΧΑΝΗ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΠΑΡΕΑ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">ΛΕΥΚΑΔΑ</span><span class="ticker-dot">·</span>
    <span class="ticker-item">SNACK</span><span class="ticker-dot">·</span>
    <span class="ticker-item">FAMILY</span><span class="ticker-dot">·</span>
  </div>
</div>


<!-- ═══ ABOUT ════════════════════════════════════════════════════════════ -->
<section class="sec" id="about">
  <div class="wrap">
    <div class="about-grid">

      <div>
        <span class="eyebrow reveal" data-i18n="about_eyebrow">Η ιστορία μας</span>
        <h2 class="sec-title reveal reveal-delay-1" data-i18n="about_title">Οικογένεια,<br>καφές &amp; δρόμος.</h2>
        <div class="thin-rule reveal reveal-delay-2"></div>
        <p class="sec-body reveal reveal-delay-2" data-i18n="about_body1">
          Στο κέντρο των Καριωτών, στην καρδιά της Λευκάδας, το «Πάρε &amp; Έφυγες» είναι κάτι παραπάνω από ένα καφέ. Είναι ένας τόπος συνάντησης — για ντόπιους, για ταξιδιώτες, για αυτούς που σταματούν με τη μηχανή.
        </p>
        <p class="sec-body reveal reveal-delay-3" style="margin-top:1rem;" data-i18n="about_body2">
          Οικογενειακή επιχείρηση με ψυχή — σερβίρουμε εξαιρετικό καφέ και σνακ σε ένα περιβάλλον που νιώθεις σαν σπίτι, ή σαν την αρχή μιας ωραίας διαδρομής.
        </p>
        <div class="about-stats reveal reveal-delay-4">
          <div>
            <span class="stat-num">100%</span>
            <span class="stat-label" data-i18n="stat1">Οικογενειακό</span>
          </div>
          <div>
            <span class="stat-num" id="statRating">★ 5.0</span>
            <span class="stat-label" data-i18n="stat2">Google Rating</span>
          </div>
          <div>
            <span class="stat-num">∞</span>
            <span class="stat-label" data-i18n="stat3">Φλιτζάνια καφέ</span>
          </div>
        </div>
      </div>

      <div class="about-visual reveal reveal-delay-2">
        <div class="about-img-frame">
          <img src="<?php echo get_template_directory_uri(); ?>/Logo.jpeg" alt="Πάρε & Έφυγες Logo">
        </div>
      </div>

    </div>
  </div>
</section>


<!-- ═══ COFFEE ════════════════════════════════════════════════════════════ -->
<section class="sec" id="coffee">
  <div class="wrap">
    <div class="coffee-header">
      <span class="eyebrow reveal" data-i18n="coffee_eyebrow">Για κάθε γούστο</span>
      <h2 class="sec-title reveal reveal-delay-1" data-i18n="coffee_title">Ο Καφές μας</h2>
      <div class="thin-rule center reveal reveal-delay-2"></div>
      <p class="sec-body reveal reveal-delay-2" style="max-width:500px;margin:0 auto;" data-i18n="coffee_sub">
        Από τον πρωινό ελληνικό ως το βραδινό freddo — κάθε φλιτζάνι φτιάχνεται με μεράκι.
      </p>
    </div>

    <div class="coffee-grid">
      <div class="coffee-card reveal reveal-delay-1">
        <svg class="coffee-icon" viewBox="0 0 52 52" fill="none">
          <path d="M12 30 L14 44 L38 44 L40 30 Z" fill="currentColor" opacity="0.7"/>
          <rect x="10" y="28" width="32" height="5" rx="2.5" fill="currentColor"/>
          <path d="M40 32 Q49 32 49 38 Q49 44 40 44" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>
          <path d="M20 22 Q18 15 20 8" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.55"/>
          <path d="M26 24 Q24 16 26 8" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.55"/>
          <path d="M32 22 Q30 15 32 8" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.55"/>
        </svg>
        <h3 class="coffee-name" data-i18n="c1_name">Ελληνικός</h3>
        <p class="coffee-desc" data-i18n="c1_desc">Ο αληθινός, ο παραδοσιακός. Σκέτος, μέτριος ή γλυκός — όπως τον αγαπάς.</p>
      </div>

      <div class="coffee-card reveal reveal-delay-2">
        <svg class="coffee-icon" viewBox="0 0 52 52" fill="none">
          <rect x="17" y="14" width="18" height="30" rx="4" stroke="currentColor" stroke-width="2.5" fill="none"/>
          <path d="M21 14 L19 8 L33 8 L31 14" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/>
          <line x1="26" y1="24" x2="26" y2="40" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <circle cx="26" cy="20" r="3.5" fill="currentColor" opacity="0.5"/>
          <path d="M20 19 Q26 15 32 19" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.8"/>
        </svg>
        <h3 class="coffee-name" data-i18n="c2_name">Freddo Espresso</h3>
        <p class="coffee-desc" data-i18n="c2_desc">Δυνατός, παγωμένος, αναζωογονητικός. Ο αγαπημένος του καλοκαιριού.</p>
      </div>

      <div class="coffee-card reveal reveal-delay-3">
        <svg class="coffee-icon" viewBox="0 0 52 52" fill="none">
          <path d="M12 32 L14 45 L38 45 L40 32 Z" fill="currentColor" opacity="0.7"/>
          <rect x="10" y="30" width="32" height="5" rx="2.5" fill="currentColor"/>
          <path d="M14 30 Q26 18 38 30" stroke="currentColor" stroke-width="3" fill="currentColor" opacity="0.35"/>
          <path d="M40 34 Q49 34 49 40 Q49 46 40 46" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        </svg>
        <h3 class="coffee-name" data-i18n="c3_name">Freddo Cappuccino</h3>
        <p class="coffee-desc" data-i18n="c3_desc">Κρεμώδης αφρός, παγωμένο espresso. Η τέλεια ισορροπία.</p>
      </div>

      <div class="coffee-card reveal reveal-delay-4">
        <svg class="coffee-icon" viewBox="0 0 52 52" fill="none">
          <path d="M19 34 L20 44 L32 44 L33 34 Z" fill="currentColor" opacity="0.9"/>
          <rect x="17" y="32" width="18" height="5" rx="2.5" fill="currentColor"/>
          <path d="M33 35 Q41 35 41 39 Q41 44 33 44" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>
          <path d="M24 26 Q22 20 24 14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.65"/>
          <path d="M28 28 Q26 21 28 13" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.65"/>
          <ellipse cx="26" cy="46" rx="10" ry="2.5" fill="currentColor" opacity="0.2"/>
        </svg>
        <h3 class="coffee-name" data-i18n="c4_name">Espresso</h3>
        <p class="coffee-desc" data-i18n="c4_desc">Μικρός αλλά δυνατός. Για όσους ξέρουν τι θέλουν.</p>
      </div>
    </div>
  </div>
</section>


<!-- ═══ VIBE / COMMUNITY ══════════════════════════════════════════════════ -->
<section id="vibe">
  <img src="<?php echo get_template_directory_uri(); ?>/Logo.jpeg" class="vibe-bg-logo" alt="" aria-hidden="true">

  <div class="wrap">
    <div class="vibe-grid">

      <div>
        <span class="eyebrow reveal" data-i18n="vibe_eyebrow">Η ψυχή μας</span>
        <blockquote class="vibe-quote reveal reveal-delay-1">
          <span data-i18n="vibe_quote">"Κάθε σταμάτημα είναι μια καλή ευκαιρία για παρέα."</span>
          <cite data-i18n="vibe_cite">— Πάρε &amp; Έφυγες, Καριώτες</cite>
        </blockquote>
        <p class="sec-body light reveal reveal-delay-2" style="margin-top:2rem;" data-i18n="vibe_body">
          Είτε έχεις σταματήσει με τη μηχανή σου για έναν καφέ, είτε ψάχνεις μια ήσυχη γωνιά για να ξεκουραστείς — εδώ θα βρεις παρέα, ζεστασιά και έναν χώρο που νιώθεις ότι ανήκεις.
        </p>
      </div>

      <div class="pillar-list">
        <div class="pillar reveal reveal-delay-1">
          <div class="pillar-icon-wrap">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
              <circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </div>
          <div>
            <div class="pillar-title" data-i18n="p1_title">Παρέα &amp; Κοινότητα</div>
            <div class="pillar-body" data-i18n="p1_body">Ένας τόπος για να συναντηθείς, να μιλήσεις, να νιώσεις ότι ανήκεις κάπου.</div>
          </div>
        </div>

        <div class="pillar reveal reveal-delay-2">
          <div class="pillar-icon-wrap">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 8h1a4 4 0 0 1 0 8h-1"/>
              <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/>
              <line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/>
            </svg>
          </div>
          <div>
            <div class="pillar-title" data-i18n="p2_title">Εξαιρετικός Καφές</div>
            <div class="pillar-body" data-i18n="p2_body">Φτιαγμένος με μεράκι και αγάπη — κάθε φλιτζάνι είναι μια μικρή τελετή.</div>
          </div>
        </div>

        <div class="pillar reveal reveal-delay-3">
          <div class="pillar-icon-wrap">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0"/>
              <path d="M12 8v4l3 3"/>
            </svg>
          </div>
          <div>
            <div class="pillar-title" data-i18n="p3_title">Πνεύμα Ελευθερίας</div>
            <div class="pillar-body" data-i18n="p3_body">Η μηχανή, ο δρόμος, ο αέρας της Λευκάδας — εδώ γιορτάζουμε την ελευθερία της στιγμής.</div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


<!-- ═══ REVIEWS ═══════════════════════════════════════════════════════════ -->
<section class="sec" id="reviews">
  <div class="wrap">
    <div class="reviews-header">
      <span class="eyebrow reveal" data-i18n="rev_eyebrow">Τι λένε οι επισκέπτες μας</span>
      <h2 class="sec-title reveal reveal-delay-1" data-i18n="rev_title">Κριτικές Google</h2>
      <div class="thin-rule center reveal reveal-delay-2"></div>
    </div>

    <div class="reviews-grid" id="reviewsGrid">
      <div class="review-card reveal reveal-delay-1">
        <svg class="g-icon" width="20" height="20" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
        <span class="review-stars">★★★★★</span>
        <p class="review-text" data-i18n="r1">"Ένα νέο μαγαζί για καφέ και σνακ, πάνω στον δρόμο. Πολύ ωραίος χώρος και εξυπηρέτηση!"</p>
        <div class="review-author-row">
          <div class="review-avatar">Β</div>
          <div>
            <div class="review-name">Βασίλης</div>
            <div class="review-source">Google Review</div>
          </div>
        </div>
      </div>
      <div class="review-card reveal reveal-delay-2">
        <svg class="g-icon" width="20" height="20" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
        <span class="review-stars">★★★★★</span>
        <p class="review-text" data-i18n="r2">"Πολύ ωραίος καφές, άψογα φτιαγμένος. Εξυπηρέτηση άριστη!"</p>
        <div class="review-author-row">
          <div class="review-avatar">Γ</div>
          <div>
            <div class="review-name">Γιώργος Κυριαζής</div>
            <div class="review-source">Google Review</div>
          </div>
        </div>
      </div>
    </div>

    <div class="reviews-cta reveal">
      <a href="https://maps.app.goo.gl/YqieBPJPTxtcZChj7" target="_blank" rel="noopener" class="btn-outlined">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        <span data-i18n="rev_cta">Δες όλες τις κριτικές στο Google</span>
      </a>
    </div>
  </div>
</section>


<!-- ═══ GALLERY ══════════════════════════════════════════════════════════ -->
<section class="sec" id="gallery">
  <div class="wrap">
    <div class="gallery-header">
      <span class="eyebrow reveal" data-i18n="gal_eyebrow">Από κοντά</span>
      <h2 class="sec-title reveal reveal-delay-1" data-i18n="gal_title">Η Ατμόσφαιρά μας</h2>
      <div class="thin-rule center reveal reveal-delay-2"></div>
    </div>
    <div class="gallery-grid" id="galleryGrid"></div>
  </div>
</section>

<div class="lightbox" id="lightbox" onclick="closeLightbox()">
  <button class="lightbox-close" aria-label="Schließen" onclick="closeLightbox()">×</button>
  <img id="lightboxImg" src="" alt="">
</div>


<!-- ═══ LOCATION ══════════════════════════════════════════════════════════ -->
<section id="location">
  <div class="location-grid">
    <div class="location-info">
      <span class="eyebrow reveal" data-i18n="loc_eyebrow">Βρες μας</span>
      <h2 class="sec-title reveal reveal-delay-1" data-i18n="loc_title">Ώρες &amp; Τοποθεσία</h2>
      <div class="thin-rule reveal reveal-delay-2"></div>

      <div class="hours-table reveal reveal-delay-2" id="hoursTable">
        <div class="hours-row"><span class="hours-day" data-i18n="d_mon">Δευτέρα</span><span class="hours-time">6:00 π.μ. – 6:00 μ.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_tue">Τρίτη</span><span class="hours-time">6:00 π.μ. – 6:00 μ.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_wed">Τετάρτη</span><span class="hours-time">6:00 π.μ. – 6:00 μ.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_thu">Πέμπτη</span><span class="hours-time">6:00 π.μ. – 12:00 π.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_fri">Παρασκευή</span><span class="hours-time">12:00 π.μ. – 6:00 μ.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_sat">Σάββατο</span><span class="hours-time">6:00 π.μ. – 6:00 μ.μ.</span></div>
        <div class="hours-row"><span class="hours-day" data-i18n="d_sun">Κυριακή</span><span class="hours-time">7:00 π.μ. – 6:00 μ.μ.</span></div>
      </div>

      <div class="location-contacts reveal reveal-delay-3">
        <div class="contact-row">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          <span data-i18n="loc_addr">Καρυώτες 311 00, Ελλάδα</span>
        </div>
        <div class="contact-row" id="contactPhone">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13 19.79 19.79 0 0 1 1.61 4.38 2 2 0 0 1 3.6 2.18h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.09 6.09l.91-.91a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          <span data-i18n="loc_phone">2645 071390</span>
        </div>
        <div class="contact-row">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
          <a href="https://maps.app.goo.gl/YqieBPJPTxtcZChj7" target="_blank" rel="noopener" style="color:inherit;text-decoration:none;">Google Maps</a>
        </div>
      </div>
    </div>

    <div class="location-map">
      <iframe
        src="https://maps.google.com/maps?q=38.7976814,20.7168335&z=16&output=embed"
        allowfullscreen
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        title="Χάρτης Πάρε & Έφυγες"
      ></iframe>
    </div>
  </div>
</section>


<!-- ═══ FOOTER ════════════════════════════════════════════════════════════ -->
<footer>
  <div class="footer-inner">
    <img src="<?php echo get_template_directory_uri(); ?>/Logo.jpeg" alt="Πάρε & Έφυγες" class="footer-logo">
    <ul class="footer-links">
      <li><a href="#about"    data-i18n="nav_about">Σχετικά</a></li>
      <li><a href="#coffee"   data-i18n="nav_coffee">Καφές</a></li>
      <li><a href="#vibe"     data-i18n="nav_vibe">Παρέα</a></li>
      <li><a href="#reviews"  data-i18n="nav_reviews">Κριτικές</a></li>
      <li><a href="#gallery"  data-i18n="nav_gallery">Φωτογραφίες</a></li>
      <li><a href="#location" data-i18n="nav_loc">Εύρεση</a></li>
      <li><a href="https://maps.app.goo.gl/YqieBPJPTxtcZChj7" target="_blank" rel="noopener">Google Maps</a></li>
    </ul>
    <p class="footer-copy">© 2024 Πάρε &amp; Έφυγες · Coffee &amp; Snack · Καριώτες, Λευκάδα, Ελλάδα</p>
  </div>
</footer>


<script>
let placesData = null;

const GOOGLE_SVG = `<svg class="g-icon" width="20" height="20" viewBox="0 0 24 24" aria-label="Google">
  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
</svg>`;

async function loadPlacesData() {
  try {
    const res = await fetch('<?php echo get_template_directory_uri(); ?>/places-data.json');
    if (!res.ok) return;
    placesData = await res.json();
    applyPlacesData();
  } catch { }
}

function applyPlacesData() {
  if (!placesData) return;
  const ratingEl = document.getElementById('statRating');
  if (ratingEl && placesData.rating)
    ratingEl.textContent = `★ ${placesData.rating.toFixed(1)}`;

  const phoneRow = document.getElementById('contactPhone');
  if (phoneRow && placesData.formatted_phone_number)
    phoneRow.querySelector('span').textContent = placesData.formatted_phone_number;

  document.querySelectorAll('[data-i18n="loc_addr"]').forEach(el => {
    el.textContent = lang === 'el'
      ? (placesData.formatted_address?.el ?? el.textContent)
      : (placesData.formatted_address?.en ?? el.textContent);
  });

  renderReviews();
  renderGallery();
  renderHours();
}

function renderReviews() {
  const grid = document.getElementById('reviewsGrid');
  if (!grid || !placesData?.reviews?.length) return;
  if (placesData.reviews.length >= 3) grid.classList.add('cols-3');
  else grid.classList.remove('cols-3');
  grid.innerHTML = placesData.reviews.map(r => {
    const stars   = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
    const words   = r.author_name.trim().split(/\s+/);
    const initials = words.length >= 2
      ? (words[0][0] + words[words.length - 1][0]).toUpperCase()
      : r.author_name.slice(0, 2).toUpperCase();
    const date = new Date(r.time * 1000).toLocaleDateString(
      lang === 'el' ? 'el-GR' : 'en-US', { year: 'numeric', month: 'long' });
    const safeText = r.text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `
      <div class="review-card reveal visible">
        ${GOOGLE_SVG}
        <span class="review-stars">${stars}</span>
        <p class="review-text">"${safeText}"</p>
        <div class="review-author-row">
          <div class="review-avatar">${initials}</div>
          <div>
            <div class="review-name">${r.author_name}</div>
            <div class="review-source">Google Review · ${date}</div>
          </div>
        </div>
      </div>`;
  }).join('');
}

function renderGallery() {
  const grid = document.getElementById('galleryGrid');
  if (!grid || !placesData?.photos?.length) return;
  const photos = placesData.photos;
  grid.innerHTML = photos.map((p, i) => {
    const isFirst = i === 0;
    const isWide  = i === photos.length - 1 && photos.length % 2 === 0;
    const delayClass = i > 0 ? ` reveal-delay-${Math.min(i, 4)}` : '';
    const cls = ['gallery-item reveal' + delayClass,
      isFirst ? 'gallery-featured' : '',
      isWide   ? 'gallery-wide'    : '']
      .filter(Boolean).join(' ');
    const safe = p.uri.replace(/"/g, '%22');
    return `<div class="${cls}" onclick="openLightbox('${safe}')">
      <img src="${p.uri}" alt="Φωτογραφία ${i + 1}" loading="lazy">
    </div>`;
  }).join('');
  grid.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

function openLightbox(uri) {
  const lb  = document.getElementById('lightbox');
  const img = document.getElementById('lightboxImg');
  img.src = uri;
  lb.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow = '';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeLightbox();
});

function renderHours() {
  const table = document.getElementById('hoursTable');
  if (!table || !placesData?.opening_hours?.weekday_text) return;
  const lines = placesData.opening_hours.weekday_text[lang]
    ?? placesData.opening_hours.weekday_text.el ?? [];
  if (!lines.length) return;
  table.innerHTML = lines.map(line => {
    const colon  = line.indexOf(':');
    const day    = colon > -1 ? line.slice(0, colon).trim() : line;
    const time   = colon > -1 ? line.slice(colon + 1).trim() : '';
    const closed = /closed|κλειστ/i.test(time);
    return `
      <div class="hours-row">
        <span class="hours-day">${day}</span>
        <span class="hours-time ${closed ? 'closed' : ''}">${time || '—'}</span>
      </div>`;
  }).join('');
}

const T = {
  el: {
    nav_about:'Σχετικά', nav_coffee:'Ο Καφές μας', nav_vibe:'Η Παρέα', nav_reviews:'Κριτικές', nav_gallery:'Φωτογραφίες', nav_loc:'Εύρεση',
    hero_tagline:'Coffee & Snack · Καριώτες, Λευκάδα',
    hero_sub:'Ή μείνε — δεν μας πειράζει.\nΗ καλύτερη παρέα ξεκινά πάντα με έναν καλό καφέ.',
    hero_cta1:'Ανακάλυψέ μας', hero_cta2:'Βρες μας',
    about_eyebrow:'Η ιστορία μας', about_title:'Οικογένεια,\nκαφές & δρόμος.',
    about_body1:'Στο κέντρο των Καριωτών, στην καρδιά της Λευκάδας, το «Πάρε & Έφυγες» είναι κάτι παραπάνω από ένα καφέ. Είναι ένας τόπος συνάντησης — για ντόπιους, για ταξιδιώτες, για αυτούς που σταματούν με τη μηχανή.',
    about_body2:'Οικογενειακή επιχείρηση με ψυχή — σερβίρουμε εξαιρετικό καφέ και σνακ σε ένα περιβάλλον που νιώθεις σαν σπίτι, ή σαν την αρχή μιας ωραίας διαδρομής.',
    stat1:'Οικογενειακό', stat2:'Google Rating', stat3:'Φλιτζάνια καφέ',
    coffee_eyebrow:'Για κάθε γούστο', coffee_title:'Ο Καφές μας',
    coffee_sub:'Από τον πρωινό ελληνικό ως το βραδινό freddo — κάθε φλιτζάνι φτιάχνεται με μεράκι.',
    c1_name:'Ελληνικός',        c1_desc:'Ο αληθινός, ο παραδοσιακός. Σκέτος, μέτριος ή γλυκός — όπως τον αγαπάς.',
    c2_name:'Freddo Espresso',  c2_desc:'Δυνατός, παγωμένος, αναζωογονητικός. Ο αγαπημένος του καλοκαιριού.',
    c3_name:'Freddo Cappuccino',c3_desc:'Κρεμώδης αφρός, παγωμένο espresso. Η τέλεια ισορροπία.',
    c4_name:'Espresso',         c4_desc:'Μικρός αλλά δυνατός. Για όσους ξέρουν τι θέλουν.',
    vibe_eyebrow:'Η ψυχή μας',
    vibe_quote:'"Κάθε σταμάτημα είναι μια καλή ευκαιρία για παρέα."',
    vibe_cite:'— Πάρε & Έφυγες, Καριώτες',
    vibe_body:'Είτε έχεις σταματήσει με τη μηχανή σου για έναν καφέ, είτε ψάχνεις μια ήσυχη γωνιά — εδώ θα βρεις παρέα, ζεστασιά και έναν χώρο που νιώθεις ότι ανήκεις.',
    p1_title:'Παρέα & Κοινότητα', p1_body:'Ένας τόπος για να συναντηθείς, να μιλήσεις, να νιώσεις ότι ανήκεις κάπου.',
    p2_title:'Εξαιρετικός Καφές', p2_body:'Φτιαγμένος με μεράκι και αγάπη — κάθε φλιτζάνι είναι μια μικρή τελετή.',
    p3_title:'Πνεύμα Ελευθερίας', p3_body:'Η μηχανή, ο δρόμος, ο αέρας της Λευκάδας — εδώ γιορτάζουμε την ελευθερία της στιγμής.',
    rev_eyebrow:'Τι λένε οι επισκέπτες μας', rev_title:'Κριτικές Google',
    gal_eyebrow:'Από κοντά', gal_title:'Η Ατμόσφαιρά μας',
    r1:'"Ένα νέο μαγαζί για καφέ και σνακ, πάνω στον δρόμο. Πολύ ωραίος χώρος!"',
    r2:'"Πολύ ωραίος καφές, άψογα φτιαγμένος. Εξυπηρέτηση άριστη!"',
    rev_cta:'Δες όλες τις κριτικές στο Google',
    loc_eyebrow:'Βρες μας', loc_title:'Ώρες & Τοποθεσία',
    loc_addr:'Καρυώτες 311 00, Ελλάδα', loc_phone:'2645 071390',
    d_mon:'Δευτέρα', d_tue:'Τρίτη', d_wed:'Τετάρτη',
    d_thu:'Πέμπτη', d_fri:'Παρασκευή', d_sat:'Σάββατο', d_sun:'Κυριακή',
  },
  en: {
    nav_about:'About', nav_coffee:'Our Coffee', nav_vibe:'The Vibe', nav_reviews:'Reviews', nav_gallery:'Photos', nav_loc:'Find Us',
    hero_tagline:'Coffee & Snack · Kariotes, Lefkada',
    hero_sub:'Or stay — we don\'t mind.\nThe best company always starts with a great coffee.',
    hero_cta1:'Discover Us', hero_cta2:'Find Us',
    about_eyebrow:'Our Story', about_title:'Family,\ncoffee & the road.',
    about_body1:'In the heart of Kariotes, Lefkada, "Pare & Efuges" is more than a café. It\'s a meeting point — for locals, travellers, and those who stop on their motorcycles.',
    about_body2:'A family-run business with soul — exceptional coffee and snacks in an environment where you feel at home, or like the start of a great ride.',
    stat1:'Family-Owned', stat2:'Google Rating', stat3:'Cups of coffee',
    coffee_eyebrow:'For every taste', coffee_title:'Our Coffee',
    coffee_sub:'From the morning Greek coffee to the evening freddo — every cup is made with care.',
    c1_name:'Greek Coffee',       c1_desc:'The real, the traditional. Black, medium, or sweet — just the way you love it.',
    c2_name:'Freddo Espresso',    c2_desc:'Strong, iced, refreshing. The summer favourite.',
    c3_name:'Freddo Cappuccino',  c3_desc:'Creamy foam, iced espresso. The perfect balance.',
    c4_name:'Espresso',           c4_desc:'Small but mighty. For those who know what they want.',
    vibe_eyebrow:'Our soul',
    vibe_quote:'"Every stop is a good reason to make new friends."',
    vibe_cite:'— Pare & Efuges, Kariotes',
    vibe_body:'Whether you\'ve stopped with your bike for a coffee, or you\'re looking for a quiet corner — here you\'ll find company, warmth, and a place where you belong.',
    p1_title:'Community & Belonging', p1_body:'A place to meet, to talk, to feel that you belong somewhere.',
    p2_title:'Exceptional Coffee',    p2_body:'Made with care and love — every cup is a small ceremony.',
    p3_title:'Spirit of Freedom',     p3_body:'The bike, the road, the Lefkada breeze — here we celebrate the freedom of the moment.',
    rev_eyebrow:'What our guests say', rev_title:'Google Reviews',
    gal_eyebrow:'Up close', gal_title:'Our Atmosphere',
    r1:'"A new coffee and snack spot, right on the road. Great atmosphere!"',
    r2:'"Amazing coffee, perfectly made. Excellent service!"',
    rev_cta:'See all Google Reviews',
    loc_eyebrow:'Find us', loc_title:'Hours & Location',
    loc_addr:'Kariotes 311 00, Greece', loc_phone:'2645 071390',
    d_mon:'Monday', d_tue:'Tuesday', d_wed:'Wednesday',
    d_thu:'Thursday', d_fri:'Friday', d_sat:'Saturday', d_sun:'Sunday',
  }
};

let lang = 'el';

function setLang(l) {
  lang = l;
  document.documentElement.lang = l;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.getAttribute('data-i18n');
    if (T[l][k] !== undefined) el.textContent = T[l][k];
  });
  document.getElementById('btnEl').classList.toggle('active', l === 'el');
  document.getElementById('btnEn').classList.toggle('active', l === 'en');
  document.getElementById('btnEl').setAttribute('aria-pressed', l === 'el');
  document.getElementById('btnEn').setAttribute('aria-pressed', l === 'en');
  if (placesData) {
    renderHours();
    document.querySelectorAll('[data-i18n="loc_addr"]').forEach(el => {
      el.textContent = l === 'el'
        ? (placesData.formatted_address?.el ?? el.textContent)
        : (placesData.formatted_address?.en ?? el.textContent);
    });
  }
}

const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });

function toggleMenu() {
  document.getElementById('navLinks').classList.toggle('open');
}
document.querySelectorAll('#navLinks a').forEach(a =>
  a.addEventListener('click', () => document.getElementById('navLinks').classList.remove('open'))
);

const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

loadPlacesData();
</script>

</body>
</html>
